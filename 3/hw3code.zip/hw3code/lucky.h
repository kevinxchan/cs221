#ifndef LUCKY_H
#define LUCKY_H

unsigned long lucky(unsigned long n);

unsigned long dp_lucky(unsigned long n);

float recpow(float x, unsigned long n);

unsigned long gold_lucky(unsigned long n);

#endif /* LUCKY_H */
